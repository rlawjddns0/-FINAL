package com.ssafy.pass.dto;

import java.util.Date;

public class Board {
	private int no;
	private String writer;
	private String title;
	private String contents;
	private Date date;
	@Override
	public String toString() {
		return "Board [no=" + no + ", writer=" + writer + ", title=" + title + ", contents=" + contents + ", date="
				+ date + "]";
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Board(int no, String writer, String title, String contents, Date date) {
		super();
		this.no = no;
		this.writer = writer;
		this.title = title;
		this.contents = contents;
		this.date = date;
	}
	public Board(int no, String writer, String title, String contents) {
		super();
		this.no = no;
		this.writer = writer;
		this.title = title;
		this.contents = contents;
	}
	public Board( String writer, String title, String contents, Date date) {
		super();
		this.writer = writer;
		this.title = title;
		this.contents = contents;
		this.date = date;
	}
	public Board( String writer, String title, String contents) {
		super();
		this.writer = writer;
		this.title = title;
		this.contents = contents;
	}
	public Board() {
		super();
	}
	
	
	
	
}
