package com.ssafy.pass.dto;

import java.util.Date;

public class Member {
	private String userid;
	private String username;
	private String userpwd;
	private String email;
	private String address;
	private Date joindate;
	@Override
	public String toString() {
		return "Member [userid=" + userid + ", username=" + username + ", userpwd=" + userpwd + ", email=" + email
				+ ", address=" + address + ", date=" + joindate + "]";
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpwd() {
		return userpwd;
	}
	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getDate() {
		return joindate;
	}
	public void setDate(Date date) {
		this.joindate = date;
	}
	public Member(String userid, String username, String userpwd, String email, String address, Date joindate) {
		super();
		this.userid = userid;
		this.username = username;
		this.userpwd = userpwd;
		this.email = email;
		this.address = address;
		this.joindate = joindate;
	}
	
	public Member(String userid, String userpwd) {
		super();
		this.userid = userid;
		this.userpwd = userpwd;
	}
	public Member() {
		super();
	}
	public Member(String userid, String username, String userpwd, String email, String address) {
		super();
		this.userid = userid;
		this.username = username;
		this.userpwd = userpwd;
		this.email = email;
		this.address = address;
	}
	public String getPassWord() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setPassWord(String userPwd2) {
		// TODO Auto-generated method stub
		
	}
	
	
}
