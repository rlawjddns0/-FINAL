package com.ssafy.pass.service;

import java.util.Map;

import com.ssafy.pass.dto.Member;

public interface MemberService {
//	회원가입
	void registerMember(Member member);
	
//	로그인
	Member login(Map<String,String> user);
	
//	회원정보 수정을 위한 회원의 모든 정보 얻기
	Member getMember(String userId);
//	회원정보 수정
	void modifyMember(Member member);
	
//	회원탈퇴
	void deleteMember(String userId);
}
