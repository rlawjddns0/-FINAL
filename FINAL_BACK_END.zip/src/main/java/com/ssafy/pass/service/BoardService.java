package com.ssafy.pass.service;

import java.util.List;
import java.util.Map;

import com.ssafy.pass.dto.Board;
import com.ssafy.pass.util.PageNavigation;

public interface BoardService {
	//모든 리스트 가져오기
	List<Board> selectAll(Map<String, String> map);
	//리스트 하나 가져오기
	Board select(int no);
	//수정
	int modifyBoard(Board board);
	//삭제
	int deleteBoard(int no);
	//입력
	int insertBoard(Board board);
	
	public PageNavigation makePageNavigation(Map<String, String> map) throws Exception;
	

}
