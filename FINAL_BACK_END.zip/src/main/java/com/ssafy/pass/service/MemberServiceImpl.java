package com.ssafy.pass.service;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.pass.dto.Member;
import com.ssafy.pass.dao.MemberMapper;

@Service("MemberServiceImpl")
public class MemberServiceImpl implements MemberService {

	
	@Autowired
	SqlSession sqlSession;
	
	@Override
	public void registerMember(Member member) {
		sqlSession.getMapper(MemberMapper.class).registerMember(member);
	}

	@Override
	public Member login(Map<String,String> user) {
		// TODO Auto-generated method stub
		return sqlSession.getMapper(MemberMapper.class).login(user);
	}

	@Override
	public Member getMember(String userId) {
		// TODO Auto-generated method stub
		return sqlSession.getMapper(MemberMapper.class).getMember(userId);
	}

	@Override
	public void modifyMember(Member member) {
		sqlSession.getMapper(MemberMapper.class).modifyMember(member);
		
	}

	@Override
	public void deleteMember(String userId) {
		sqlSession.getMapper(MemberMapper.class).deleteMember(userId);;
		
	}
	
	
}
