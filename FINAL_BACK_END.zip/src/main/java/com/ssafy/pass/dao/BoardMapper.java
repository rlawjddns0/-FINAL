package com.ssafy.pass.dao;

import java.util.List;
import java.util.Map;

import com.ssafy.pass.dto.Board;

public interface BoardMapper {
	//모든 리스트 가져오기
		List<Board> selectAll(Map<String, Object> map);
		//리스트 하나 가져오기
		Board select(int no);
		//수정
		int modifyBoard(Board board);
		//삭제
		int deleteBoard(int no);
		//입력
		int insertBoard(Board board);
		
		public int getTotalCount(Map<String, String> map);
}
