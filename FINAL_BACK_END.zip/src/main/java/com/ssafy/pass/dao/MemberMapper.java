package com.ssafy.pass.dao;

import java.util.Map;

import com.ssafy.pass.dto.Member;

public interface MemberMapper {
	void registerMember(Member member);

	Member login(Map<String,String> user);

	Member getMember(String userId);

	void modifyMember(Member member);

	void deleteMember(String userId);
}
