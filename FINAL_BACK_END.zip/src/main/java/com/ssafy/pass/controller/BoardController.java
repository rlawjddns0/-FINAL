package com.ssafy.pass.controller;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.pass.dto.Board;
import com.ssafy.pass.service.BoardService;
import com.ssafy.pass.util.PageNavigation;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
@CrossOrigin(origins={"*"}, maxAge=6000)
@RestController
@RequestMapping("/api")
@Api(value="Board")
public class BoardController {
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	
	@Autowired
	@Qualifier("BoardServiceImpl")
	private BoardService boardSer;
	
	
	@RequestMapping(value="/board/list", method=RequestMethod.GET)
	@ApiOperation(value="board 리스트 가져오기", response=List.class)
	public ResponseEntity<Map<String, Object>> boardList( @RequestParam(required = false, defaultValue = "10") String spp, @RequestParam(required = false) String key,
	        @RequestParam(required = false) String word, @RequestParam(required = false, defaultValue = "1") String pg){
		Map<String, String> map=new HashMap<>();
		System.out.println(spp);
		System.out.println(pg);
		System.out.println(key);
		System.out.println(word);
	    map.put("spp", spp);// sizePerPage
	    map.put("pg", pg);// currentPage
	    map.put("key", key);
	    map.put("word", word);
		try {
			List<Board> list=boardSer.selectAll(map);
			PageNavigation navigation = boardSer.makePageNavigation(map);
			Map<String, Object> result = new HashMap<>();
			System.out.println(list.toString());
			if(list.size()==0) {
				return new ResponseEntity(HttpStatus.NO_CONTENT);
			}else {
				result.put("list", list);
				result.put("navigation", navigation);
				System.out.println("성공 "+list.toString());
				return new ResponseEntity<Map<String, Object>>(result,HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		
	}
	
	
	@ApiOperation(value="새로운 게시판 정보 입력")
	@PostMapping(value="/board/insert")
	public ResponseEntity<Map<String, Object>> boardInsert(@RequestBody Board board){
		ResponseEntity<Map<String, Object>> resEntity = null;
		try {
			System.out.println(board.toString());
			int insert = boardSer.insertBoard(board);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "입력 성공");
			map.put("resValue", insert);
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		} catch(RuntimeException e) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "입력 실패");
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		}
		return resEntity;
		
	}
	@ApiOperation(value="선택한 게시판 정보 하나 리턴")
	@GetMapping(value="/board/{no}")
	public ResponseEntity<Board> select(@PathVariable("no") String no) {
		System.out.println(no);
		try {
			Board board=boardSer.select(Integer.parseInt(no));
			System.out.println(board.toString());
			return new ResponseEntity<Board>(boardSer.select(Integer.parseInt(no)), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}//read
	
	@ApiOperation(value="선택한 글 삭제")
	@DeleteMapping(value="/board/{no}")
	public ResponseEntity<Map<String, Object>> boardInsert(@PathVariable("no") String no){
		ResponseEntity<Map<String, Object>> resEntity = null;
		try {
			System.out.println(no);
			int delete = boardSer.deleteBoard(Integer.parseInt(no));
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "삭제 성공");
			map.put("resValue", delete);
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		} catch(RuntimeException e) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "삭제 실패");
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		}
		return resEntity;
		
	}
	@ApiOperation(value="선택한 글 수정")
	@PutMapping(value="/board/modify")
	public ResponseEntity<Map<String, Object>> boardModify(@RequestBody Board board){
		ResponseEntity<Map<String, Object>> resEntity = null;
		try {
			System.out.println(board.toString());
			int modify = boardSer.modifyBoard(board);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "수정 성공");
			map.put("resValue", modify);
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		} catch(RuntimeException e) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "수정 실패");
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		}
		return resEntity;
		
	}
	
	
	
	
	

}
