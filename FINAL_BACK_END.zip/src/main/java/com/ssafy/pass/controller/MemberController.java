package com.ssafy.pass.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.pass.dto.Member;
import com.ssafy.pass.service.MemberService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
@CrossOrigin(origins={"*"}, maxAge=6000)
@RestController
@RequestMapping("/api")
@Api(value="Member")
public class MemberController {
	
	@Autowired
	@Qualifier("MemberServiceImpl")
	private MemberService memSer; 
	

	@ApiOperation(value="회원 가입")
	@PostMapping(value="/mem/register")
	public ResponseEntity<Map<String, Object>> register(@RequestBody Member member){
		ResponseEntity<Map<String, Object>> resEntity = null;

		try {
			System.out.println(member.toString());
			memSer.registerMember(member);
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "회원가입 성공");
			map.put("resValue", 1);
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		} catch (Exception e) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "회원가입 실패");
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		}
		return resEntity;
	}
	@ApiOperation(value="회원 정보 수정")
	@PostMapping(value="/mem/modify")
	public ResponseEntity<Map<String, Object>> modify(@RequestBody Member member){
		ResponseEntity<Map<String, Object>> resEntity = null;
		
		try {
			System.out.println(member.toString());
			memSer.modifyMember(member);
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "회원정보수정 성공");
			map.put("resValue", 1);
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		} catch (Exception e) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "회원정보수정 실패");
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		}
		return resEntity;
	}
	@ApiOperation(value="회원 탈퇴")
	@PostMapping(value="/mem/delete")
	public ResponseEntity<Map<String, Object>> delete(@RequestBody String userid){
		ResponseEntity<Map<String, Object>> resEntity = null;
		
		try {
			System.out.println(userid);
			memSer.deleteMember(userid);
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "회원탈퇴 성공");
			map.put("resValue", 1);
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		} catch (Exception e) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("resmsg", "회원탈퇴 실패");
			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
		}
		return resEntity;
	}
//	
	
	

	@ApiOperation(value="로그인 후 맞는 정보가 있으면 member 리턴")
	@PostMapping(value="/mem/login")
	public ResponseEntity<Map<String, Object>> login(@RequestBody Member LoginUser) {
		System.out.println(LoginUser.getUserid());
		System.out.println(LoginUser.getUserpwd());
		Map<String, String> user=new HashMap<String, String>();
		user.put("userid",LoginUser.getUserid());
		user.put("userpwd", LoginUser.getUserpwd());
		ResponseEntity<Map<String, Object>> resEntity = null;
		try {
			
			Member userInfo=null;
			userInfo=memSer.login(user);
			if(userInfo!=null) {
				System.out.println("로그인 성공");
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("resmsg", "로그인 성공");
				map.put("resValue", userInfo);
				resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
			}
			else {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("resmsg", "로그인 실패");
				resEntity= new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resEntity;
		
	}
	
	
//	@RequestMapping(value="/userinfo",method= {RequestMethod.POST,RequestMethod.GET})
//	public String userinfo() {
//	
//		return "member/userinfo";
//	}
//	@RequestMapping(value="/usermodify",method= {RequestMethod.POST,RequestMethod.GET})
//	public String usermodify() {
//		
//		return "member/usermodify";
//	}
//	@RequestMapping(value="/attentionLocationRegForm",method= {RequestMethod.POST,RequestMethod.GET})
//	public String attentionLocationRegForm() {
//		
//		return "member/attentionLocationRegForm";
//	}
//	@RequestMapping(value="/modifyMember",method= {RequestMethod.POST,RequestMethod.GET})
//	public String modifyMember(Member mem, Model model, HttpServletRequest req){
//		System.out.println(mem.toString());
//		try {
//			memSer.modifyMember(mem);
//			Member newuser=memSer.getMember(mem.getUserid());
//			req.getSession().invalidate();
//			HttpSession session=req.getSession();
//			session.setAttribute("userinfo", newuser);
//			model.addAttribute("msg","회원 수정 성공");
//			return "member/userinfo";
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		model.addAttribute("msg","회원 수정 실패");
//		return "member/userinfo";
//	}
//	@RequestMapping(value="/delete",method= {RequestMethod.POST,RequestMethod.GET})
//	public String delete(HttpServletRequest req, Model model) {
//		Member user=(Member) req.getSession().getAttribute("userinfo");
//		try {
//			System.out.println(user.getUserid());
//			memSer.deleteMember(user.getUserid());
//			HttpSession session=req.getSession();
//			session.invalidate();
//			model.addAttribute("msg","회원 탈퇴 성공");
//		} catch (Exception e) {
//		
//			e.printStackTrace();
//		
//		}
//		return "index";
//	}
//	@RequestMapping(value="/logout",method= {RequestMethod.POST,RequestMethod.GET})
//	public String logout(HttpServletRequest req,Model model ) {
//		
//		HttpSession session=req.getSession();
//		session.invalidate();
//		model.addAttribute("msg","로그아웃");
//		
//		return "index";
//	}

}
