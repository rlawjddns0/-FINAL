package com.ssafy.pass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(FinalProject1Application.class, args);
	}

}
