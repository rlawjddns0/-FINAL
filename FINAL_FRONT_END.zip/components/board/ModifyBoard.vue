<template>
  <div>
    <write-form type="modify" />
  </div>
</template>

<script>
import WriteForm from "@/components/board/include/WriteForm.vue";
export default {

    name: "ModifyBoard",
    components: {
        WriteForm
    }




}
</script>

<style>

</style>