function test() {
  console.log("테스트");
}

export default test