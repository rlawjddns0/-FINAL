<template>
  <div>
    <regist-form type="modify" />
  </div>
</template>

<script>
import RegistForm from "@/components/user/RegisterForm.vue"

export default {
  name: "Regist",
  components: {
    RegistForm
  }
};
</script>