<template>
  <div>
    <regist-form type="regist" />
  </div>
</template>

<script>
import RegistForm from "@/components/user/RegisterForm.vue"

export default {
  name: "Regist",
  components: {
    RegistForm
  }
};
</script>
